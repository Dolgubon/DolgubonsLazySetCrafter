-- Dolgubon's Lazy Set Crafter
-- Created December 2016
-- Last Modified: December 23 2016
-- 
-- Created by Dolgubon (Joseph Heinzle)
-----------------------------------
--

-----------------------------------
--Addon Namespace creation
DolgubonSetCrafter = DolgubonSetCrafter or {}


------------------------------------
-- TRAIT DECLARATION
DolgubonSetCrafter.weaponTraits = {}
for i = 0, 8 do --create the weapon trait table
	--Takes the strings starting at SI_ITEMTRAITTYPE0 == no trait, # 897 to SI_ITEMTRAITTYPE8 === Divines, #905
	--Then saves the proper trait index used for crafting to it. The offset of 1 is due to ZOS; the offset of STURDY is so they start at 12
	DolgubonSetCrafter.weaponTraits[i + 1] = {[1]  = i + 1, [2] = GetString(SI_ITEMTRAITTYPE0 + i),}
end

DolgubonSetCrafter.armourTraits = {}
for i = 0, 7 do --create the armour trait table
	--Takes the strings starting at SI_ITEMTRAITTYPE11 == Sturdy, # 908 to SI_ITEMTRAITTYPE18 === Divines, #915
	--Then saves the proper trait index used for crafting to it. The offset of 1 is due to ZOS; the offset of STURDY is so they start at 12
	DolgubonSetCrafter.armourTraits[i + 1] = {[1] = i + 1 + ITEM_TRAIT_TYPE_ARMOR_STURDY, [2] = GetString(SI_ITEMTRAITTYPE11 + i)}
end
--Add a few missing traits to the tables - i.e., nirnhoned, and no trait
DolgubonSetCrafter.armourTraits[#DolgubonSetCrafter.armourTraits + 1] = {[1] = ITEM_TRAIT_TYPE_NONE + 1, [2] = GetString(SI_ITEMTRAITTYPE0)} -- No Trait to armour traits
DolgubonSetCrafter.armourTraits[#DolgubonSetCrafter.armourTraits + 1] = {[1] = ITEM_TRAIT_TYPE_ARMOR_NIRNHONED + 1, [2] = GetString(SI_ITEMTRAITTYPE26)} -- Nirnhoned
DolgubonSetCrafter.weaponTraits[#DolgubonSetCrafter.weaponTraits + 1] = {[1] = ITEM_TRAIT_TYPE_WEAPON_NIRNHONED + 1, [2] = GetString(SI_ITEMTRAITTYPE25)}  -- Nirnhoned

--------------------------------------
--- STYLES

local bretonFlavour = GetItemLinkFlavorText(GetSmithingStyleItemLink(2 , 0))
local FlavourText = GetItemLinkFlavorText(GetSmithingStyleItemLink(3 , 0)) -- actually redguard

-- This function is to find out how long of a string should be cut out from the start and the end of trait tooltip
local function isolateStyleName()
	
	if bretonFlavour == FlavourText then return "Breton" end
	local i = 1
	while string.sub(bretonFlavour , i, i) == string.sub(FlavourText , i, i) do 
		i = i + 1
	end
	local start = i
	i = 0
	while string.sub(bretonFlavour , string.len(bretonFlavour)-i, string.len(bretonFlavour)-i) == string.sub(FlavourText , string.len(FlavourText)-i, string.len(FlavourText)-i) do 
		i = i + 1
	end
	return start, i
end
local startExtras, endExtras = isolateStyleName()

--setup Style Table

local styles = {}
for i = 1, GetNumSmithingStyleItems() do
	if GetString("SI_ITEMSTYLE", i)~="" and i~=10 and i<48 then

		styles[#styles + 1] = {i+1 ,GetString("SI_ITEMSTYLE", i),}
		
	end
end
DolgubonSetCrafter.styleNames = styles

------------------------------------
-------- QUALITY

--Setup quality table
DolgubonSetCrafter.quality = {}

for i = 1, 5 do
	DolgubonSetCrafter.quality[i] = {[1] = i, [2] = GetString(SI_ITEMQUALITY0 + i)}
end

--------------------------------------
--------- CRAFTING REQUIREMENTS

-- This is a bit more esoteric, in how it's set up. Basically, crafting requirements mainly follow a few patterns
-- About 75% of them follow the pattern. Greaves are odd just because, but the other 8 follow a second pattern.
-- The second pattern only changes at the highest levels. The following reduces the pattern.

local requirementJumps = { -- At these material indexes, the material required changes, and the amount required jumps down
	[1] = 1,
	[2] = 8,
	[3] = 13,
	[4] = 18,
	[5] = 23,
	[6] = 26,
	[7] = 29,
	[8] = 32,
	[9] = 34,
	[10] = 40,
}

local additionalRequirements = -- Seperated by station. The additional amount of mats added to the base amount.
{
	[CRAFTING_TYPE_BLACKSMITHING] = 
	{ 2, 2, 2, 4, 4, 4, 1, 6, 4, 4, 4, 5, 4, 4,
	},
	[CRAFTING_TYPE_WOODWORKING] = 
	{ 2, 5, 2, 2, 2, 2,
	},
	[CRAFTING_TYPE_CLOTHIER] = 
	{ 6, 6, 4, 4, 4, 5, 4, 4, 6, 4, 4, 4, 5, 4, 4,

	},
}

local currentStep = 1
local baseRequirements = {}
for i = 1, 41 do
	if requirementJumps[currentStep] == i then
		currentStep = currentStep + 1
		baseRequirements[i] = currentStep
	else
		baseRequirements[i] = baseRequirements[i-1] + 1
	end
end

local function GetMatRequirements(pattern, index, station)
	local mats
	--d(index, station, pattern)
	mats = baseRequirements[index] + additionalRequirements[station][pattern]
	if station == CRAFTING_TYPE_WOODWORKING and pattern ~= 2 and index >=40 then
		mats = mats + 1
	end

	if station == CRAFTING_TYPE_BLACKSMITHING and pattern ==12 and index <13 and index >=8 then
		mats = mats - 1
	end

	if station == CRAFTING_TYPE_BLACKSMITHING and pattern >=4 and pattern <=6 and index >= 40 then
		mats = mats + 1
	end
	return mats
end

DolgubonSetCrafter.setIndexes = {}
local t = GetSetIndexes()
for i, value in pairs(t) do
	DolgubonSetCrafter.setIndexes[i] = {}
	DolgubonSetCrafter.setIndexes[i][2] = t[i][1]
	DolgubonSetCrafter.setIndexes[i][1] = i
end
DolgubonSetCrafter.setIndexes[0] = {[1] = 0, [2] = "No Set"}



local queue = {}

local craftedItems = {}

local function craftTopFunction()

end

local function findPreviouslyCraftedItem()

end

local function 
